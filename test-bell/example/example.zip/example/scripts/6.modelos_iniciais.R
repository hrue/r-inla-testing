library(dplyr)
library(readr)
library(INLA)

df = read_csv('data/base_consolidada_final')

df |> head()

#finalmente, um Id para a interação área x ano
df$idInteraction = as.numeric(interaction(df$idAno, df$idArea, drop = T))

#separação da base em treino e teste
df_treino = df |> filter(ano < 2016)
df_teste = df |> filter(ano >= 2016)
df_treino$idAno1 = df_treino$idAno

#poisson, nbinomial2, zeroinflatedpoisson0, zeroinflatednbinomial2  ok

formula = numCasos ~ 1 + offset(log(populacao)) +
  indHabitSanit + propAreaFlorRem + avgAreaTempAnom + 
  f(as.character(mes), model = 'iid') +
  f(tipoMalaria, model = 'iid') + 
  f(idArea, model = 'bym2', graph = 'outputs/amazon.graph') +
  f(idAno, model = 'rw2') +
  f(idInteraction, model = 'iid')


teste_mod = inla(formula = formula, family = 'bell',
                 data = df_treino, working.directory = 'D:/INLA/',
                 control.predictor = list(compute = TRUE),
                 control.compute = list(dic = TRUE, waic = TRUE, cpo = TRUE),
                 verbose = T)
teste_mod |> summary()
